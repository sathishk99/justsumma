Font downloaded from http://www.fontget.com

To see how to install fonts go to https://www.fontget.com/help